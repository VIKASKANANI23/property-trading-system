export interface JwtTokenInterface {
  readonly id: string;
  email: string;
}
